<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <?php
        $seo = $seo ?? null;
        $metaTitle = $seo?->meta_title ?? $seo?->seo_title ?? ($defaultSeo['default_meta_title'] ?? $siteName);
        $metaDescription = $seo?->meta_description ?? ($defaultSeo['default_meta_description'] ?? '');
        $metaKeywords = $seo?->meta_keywords ?? ($defaultSeo['default_meta_keywords'] ?? '');
        $canonical = $seo?->canonical_url ?? url()->current();
        $ogTitle = $seo?->og_title ?? $metaTitle;
        $ogDescription = $seo?->og_description ?? $metaDescription;
        $ogImage = storage_url($seo?->og_image ?? ($defaultSeo['default_og_image'] ?? null));
        $robots = $seo?->robots_meta ?: ((($seo?->indexable ?? true) ? 'index' : 'noindex').', '.(($seo?->followable ?? true) ? 'follow' : 'nofollow'));
        $twitterImage = storage_url($seo?->twitter_image) ?: $ogImage;
    ?>

    <title><?php echo e($metaTitle); ?></title>
    <meta name="description" content="<?php echo e($metaDescription); ?>">
    <?php if($metaKeywords): ?><meta name="keywords" content="<?php echo e($metaKeywords); ?>"><?php endif; ?>
    <meta name="robots" content="<?php echo e($robots); ?>">
    <link rel="canonical" href="<?php echo e($canonical); ?>">

    <meta property="og:title" content="<?php echo e($ogTitle); ?>">
    <meta property="og:description" content="<?php echo e($ogDescription); ?>">
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo e($canonical); ?>">
    <?php if($ogImage): ?><meta property="og:image" content="<?php echo e($ogImage); ?>"><?php endif; ?>

    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo e($seo?->twitter_title ?? $ogTitle); ?>">
    <meta name="twitter:description" content="<?php echo e($seo?->twitter_description ?? $ogDescription); ?>">
    <?php if($twitterImage): ?>
        <meta name="twitter:image" content="<?php echo e($twitterImage); ?>">
    <?php endif; ?>

    <?php if(!empty($seo?->schema_json)): ?>
        <script type="application/ld+json"><?php echo $seo->schema_json; ?></script>
    <?php endif; ?>

    <?php if($siteLogo): ?>
        <link rel="icon" href="<?php echo e(storage_url(setting('favicon', $siteLogo, 'general'))); ?>">
    <?php endif; ?>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('assets/front/css/lyovial-home.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/front/css/site.css')); ?>" rel="stylesheet">
    <style>
        /* Brand + typography overrides (beat Bootstrap / site.css) */
        body.lyovial-home-page {
            font-family: 'Inter', sans-serif !important;
            color: #4A5A67 !important;
            background: #fff !important;
        }
        body.lyovial-home-page h1,
        body.lyovial-home-page h2,
        body.lyovial-home-page h3,
        body.lyovial-home-page .brand-text,
        body.lyovial-home-page .display-font {
            font-family: 'Inter', sans-serif !important;
        }
        body.lyovial-home-page a { color: inherit; text-decoration: none; }
        body.lyovial-home-page a:hover { color: inherit; }

        /* Navbar — match HTML theme (avoid Bootstrap .nav) */
        .lyovial-home-page .header .header-nav {
            display: flex !important;
            align-items: center;
            gap: 34px;
            margin: 0;
            padding: 0;
            list-style: none;
            flex-wrap: nowrap;
        }
        .lyovial-home-page .header .header-nav a {
            color: #fff !important;
            font-size: 14px !important;
            font-weight: 500 !important;
            letter-spacing: .2px;
            padding: 0 !important;
            margin: 0 !important;
            background: transparent !important;
            border: 0 !important;
            white-space: nowrap;
        }
        .lyovial-home-page .header .header-nav a:hover {
            color: #14a0ad !important;
        }
        .lyovial-home-page .header-cta,
        .lyovial-home-page .header-cta a,
        .lyovial-home-page .header-cta strong {
            color: #fff !important;
        }
        .lyovial-home-page .header-cta .phone-icon { color: #fff !important; }
        .lyovial-home-page .header-cta .phone-txt small { color: #fff !important; opacity: 1 !important; }

        /* Buttons */
        .lyovial-home-page .btn.btn-primary,
        .lyovial-home-page a.btn.btn-primary {
            background: #0e7c86 !important;
            border: 1.5px solid #0e7c86 !important;
            color: #fff !important;
            box-shadow: 0 4px 14px rgba(14,124,134,.35) !important;
            border-radius: 6px !important;
            padding: 16px 32px !important;
            font-weight: 600 !important;
            font-size: 14px !important;
        }
        .lyovial-home-page .btn.btn-primary:hover,
        .lyovial-home-page a.btn.btn-primary:hover,
        .lyovial-home-page .partner a.btn.btn-primary:hover {
            background: #fff !important;
            border-color: #fff !important;
            color: #0e7c86 !important;
        }
        .lyovial-home-page .partner a.btn.btn-primary {
            background: #0e7c86 !important;
            border: 1.5px solid #fff !important;
            color: #fff !important;
        }
        .lyovial-home-page .about a.btn.btn-primary {
            background: #0e7c86 !important;
            border: 1.5px solid #0e7c86 !important;
            color: #fff !important;
        }
        .lyovial-home-page .about a.btn.btn-primary:hover {
            background: #fff !important;
            border-color: #0e7c86 !important;
            color: #0e7c86 !important;
        }
        .lyovial-home-page .btn-brand {
            background: #0e7c86 !important;
            border: 1.5px solid #0e7c86 !important;
            color: #fff !important;
        }
        .lyovial-home-page .btn-brand:hover {
            background: #fff !important;
            border-color: #0e7c86 !important;
            color: #0e7c86 !important;
        }

        /* Section headings / dark text → brand teal */
        .lyovial-home-page .eyebrow,
        .lyovial-home-page .section-head h2,
        .lyovial-home-page .why-content h2,
        .lyovial-home-page .coverage-head h2,
        .lyovial-home-page .service-body h3,
        .lyovial-home-page .why-feature h3,
        .lyovial-home-page .partner-card h3,
        .lyovial-home-page .blog-body h3,
        .lyovial-home-page .coverage-item strong,
        .lyovial-home-page .blog-author strong,
        .lyovial-home-page .read-more,
        .lyovial-home-page .lyovial-faq .section-title {
            color: #0e7c86 !important;
        }
        .lyovial-home-page .read-more:hover {
            background: #0e7c86 !important;
            color: #fff !important;
        }
        .lyovial-home-page .read-more:hover svg {
            stroke: #fff !important;
            color: #fff !important;
        }
        .lyovial-home-page .eyebrow::before {
            background: #0e7c86 !important;
        }
        .lyovial-home-page .blog-head {
            text-align: left !important;
        }
        .lyovial-home-page .blog-head h2 {
            text-align: left !important;
            color: #0e7c86 !important;
        }
        .lyovial-home-page .section-head p,
        .lyovial-home-page .why-content > p,
        .lyovial-home-page .why-feature p,
        .lyovial-home-page .service-body p,
        .lyovial-home-page .partner-card p,
        .lyovial-home-page .coverage-head p {
            color: #4A5A67 !important;
        }
        .lyovial-home-page .about { background: #fff !important; color: #000 !important; }
        .lyovial-home-page .about .eyebrow { color: #0e7c86 !important; }
        .lyovial-home-page .about .eyebrow::before { background: #0e7c86 !important; }
        .lyovial-home-page .about h2 { color: #0e7c86 !important; }
        .lyovial-home-page .about p { color: #000 !important; }
        .lyovial-home-page .stats { background: #0e7c86 !important; }
        .lyovial-home-page .stat,
        .lyovial-home-page .stat-num,
        .lyovial-home-page .stat-label { color: #fff !important; }
        .lyovial-home-page .stat-icon { color: #fff !important; background: rgba(255,255,255,.15) !important; }
        .lyovial-home-page .stat-icon svg { stroke: #fff !important; }
        .lyovial-home-page .hero h1,
        .lyovial-home-page .hero p { color: #fff !important; }
        .lyovial-home-page .partner-head h2 { color: #fff !important; }
        .lyovial-home-page .partner-head .eyebrow { color: #fff !important; }
        .lyovial-home-page .partner-head .eyebrow::before { background: #fff !important; }

        .lyovial-home-page .site-footer {
            position: relative;
            z-index: 5;
            background: #0e7c86 !important;
            color: #fff !important;
        }
        .lyovial-home-page .site-footer .brand-text,
        .lyovial-home-page .site-footer h3,
        .lyovial-home-page .site-footer h4 {
            color: #fff !important;
            font-family: 'Inter', sans-serif !important;
        }
        .lyovial-home-page .site-footer a { color: rgba(255,255,255,.9) !important; }
        .lyovial-home-page .site-footer a:hover { color: #fff !important; }
        .lyovial-home-page .site-footer .footer-text { color: rgba(255,255,255,.85) !important; }
        .lyovial-home-page .site-footer .footer-bottom {
            color: rgba(255,255,255,.75) !important;
            border-top: 1px solid rgba(255,255,255,.18) !important;
        }
        .lyovial-home-page .site-footer .btn-brand {
            background: #fff !important;
            border-color: #fff !important;
            color: #0e7c86 !important;
        }
        .lyovial-home-page .site-footer .btn-brand:hover {
            background: transparent !important;
            border-color: #fff !important;
            color: #fff !important;
        }

        .lyovial-faq {
            background: var(--off-white, #F5F7F8);
            padding: 100px 0;
        }
        .lyovial-faq .section-title { color: #0e7c86 !important; font-size: 38px; font-weight: 800; font-family: 'Inter', sans-serif !important; }
        .lyovial-faq .accordion-button { color: #0e7c86 !important; font-family: 'Inter', sans-serif !important; }
        .lyovial-faq .accordion-button:not(.collapsed) { background: #fff; color: #0e7c86 !important; box-shadow: none; }
        .lyovial-faq .accordion-button:focus { box-shadow: none; border-color: var(--border, #E1E6E9); }
        .lyovial-faq .accordion-item { border-color: var(--border, #E1E6E9); }
        .lyovial-faq .accordion-body { color: #4A5A67 !important; }

        .header.nav-open .header-nav {
            display: flex !important;
            position: absolute;
            top: 100%;
            left: 0; right: 0;
            flex-direction: column;
            gap: 0 !important;
            background: #0e7c86;
            padding: 12px 24px 20px;
            z-index: 30;
        }
        .header.nav-open .header-nav a {
            display: block !important;
            padding: 12px 0 !important;
            border-bottom: 1px solid rgba(255,255,255,.08);
        }
        @media (max-width: 768px) {
            .lyovial-home-page .header .header-nav { display: none !important; }
            .lyovial-home-page .header.nav-open .header-nav { display: flex !important; }
        }
    </style>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body class="lyovial-home-page">
    <?php if(session('success')): ?>
        <div class="container pt-3" style="position:relative;z-index:30">
            <div class="alert alert-success mb-0"><?php echo e(session('success')); ?></div>
        </div>
    <?php endif; ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('front.partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.querySelector('.hamburger')?.addEventListener('click', function () {
            document.querySelector('.header')?.classList.toggle('nav-open');
        });
    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\liovine\resources\views/front/layouts/lyovial-home.blade.php ENDPATH**/ ?>